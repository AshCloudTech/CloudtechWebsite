@extends('layouts.cloudtech')

@section('title', 'Content SEO Services | Cloud Technologies Ltd')
@section('meta_title', 'Cloud Technologies Ltd – Content SEO Services')
@push('styles')
    <link rel="stylesheet" href="{{ asset('assets/services/digitalMarketing/content-seo/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/footer.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/header.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/faq.css') }}">
@endpush
@push('scripts')
    <script src="{{ asset('assets/services/digitalMarketing/content-seo/js/script.js') }}" defer></script>
@endpush
@section('content')


    <!-- HERO -->
    <section class="hero content-hero" id="hero">
        <div class="hero-bg"></div>
        <div class="hero-overlay"></div>
        <div class="container hero-grid">
            <div class="hero-text">
                <p class="hero-eyebrow">Content SEO Services</p>
                <h1>Unlock Growth Through Strategic Content Marketing Services</h1>
                <p class="hero-subtitle">
                    Boost your brand with expert content SEO services from leading content marketing agencies and companies,
                    delivering a results-driven content marketing strategy for growth.
                </p>

                <div class="hero-actions">
                    <a href="#cta" class="btn btn-lg btn-primary">Get Content Audit</a>
                    <a href="#contact-form" class="btn btn-lg btn-ghost hero-ghost-light">Discuss Strategy</a>
                </div>
            </div>

            <div class="hero-panel">
                <div class="hero-panel-inner">
                    <p class="hero-panel-label">Content Performance Snapshot</p>
                    <p class="hero-panel-text">
                        We review your existing content, identify high-potential pages and reveal
                        the gaps where strategic content can drive more organic traffic and conversions.
                    </p>
                    <ul class="hero-panel-list">
                        <li>Top-performing content</li>
                        <li>Missed keyword opportunities</li>
                        <li>Engagement and dwell time</li>
                        <li>Conversion-focused content</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- WHY CONTENT SEO MATTERS -->
    <section class="section section-alt" id="why">
        <div class="container">
            <div class="section-header">
                <h2>Why Content SEO Matters</h2>
                <p>
                    Content SEO improves visibility, attracts traffic, and strengthens brand authority.
                </p>
            </div>

            <div class="grid grid-4 why-grid">
                <article class="card why-card">
                    <div class="why-icon icon-quality"></div>
                    <h3>Quality Content</h3>
                    <p>
                        Quality Content creates value that attracts and retains your audience.
                    </p>
                </article>

                <article class="card why-card">
                    <div class="why-icon icon-keyword"></div>
                    <h3>Keyword Optimisation</h3>
                    <p>
                        Keyword Optimization aligns content with search intent for better rankings.
                    </p>
                </article>

                <article class="card why-card">
                    <div class="why-icon icon-engagement"></div>
                    <h3>User Engagement</h3>
                    <p>
                        User Engagement encourages interaction that boosts visibility and trust.
                    </p>
                </article>

                <article class="card why-card">
                    <div class="why-icon icon-authority"></div>
                    <h3>Authority Building</h3>
                    <p>
                        Authority Building establishes credibility to rank higher and earn trust.
                    </p>
                </article>
            </div>
        </div>
    </section>

    <!-- CONTENT TYPES WE OPTIMISE -->
    <section class="section" id="types">
        <div class="container">
            <div class="section-header">
                <h2>Content Types We Optimise</h2>
                <p>
                    We optimize blogs, landing pages, product content, and web copy to boost rankings and user engagement.
                </p>
            </div>

            <div class="grid grid-4 types-grid">
                <article class="card type-card">
                    <h3>Blog Posts &amp; Articles</h3>
                    <p class="type-subtitle">
                        High-quality, SEO-focused blog posts and articles crafted to increase visibility and engage your
                        audience.</p>
                    <ul>
                        <li>Keyword research</li>
                        <li>Topic clusters</li>
                        <li>Internal linking</li>
                        <li>Meta optimisation</li>
                    </ul>
                </article>

                <article class="card type-card">
                    <h3>Landing Pages</h3>
                    <p class="type-subtitle">
                        High-converting landing pages optimized for SEO, user intent, and seamless engagement.</p>
                    <ul>
                        <li>Conversion copy</li>
                        <li>SEO headlines</li>
                        <li>Call-to-actions</li>
                        <li>User experience</li>
                    </ul>
                </article>

                <article class="card type-card">
                    <h3>Product Descriptions</h3>
                    <p class="type-subtitle">
                        Compelling, SEO-friendly product descriptions that highlight features, boost visibility, and drive
                        conversions.
                    </p>
                    <ul>
                        <li>Feature Highlights</li>
                        <li>SEO Keywords</li>
                        <li>Benefit-Focused Copy</li>
                        <li>Conversion Messaging </li>
                    </ul>
                </article>

                <article class="card type-card">
                    <h3>Technical Content</h3>
                    <p class="type-subtitle">
                        Clear, accurate, and SEO-optimized technical content that simplifies complex topics and builds
                        authority.</p>
                    <ul>
                        <li>Technical Accuracy</li>
                        <li> SEO Structure</li>
                        <li>Expert Insights</li>
                        <li>Audience Clarity</li>
                    </ul>
                </article>
            </div>
        </div>
    </section>

    <!-- COMPLETE CONTENT SEO SERVICES -->
    <section class="section section-services" id="services">
        <div class="container">
            <div class="services-layout">
                <div class="services-copy">
                    <h2>Complete Content SEO Services</h2>
                    <p class="services-intro">
                        Our Complete Content SEO Services enhance search visibility through smart keyword research,
                        optimized content, and continuous improvements to drive qualified traffic and long-term growth.
                    </p>
                    <ul class="services-list">
                        <li>Comprehensive keyword research to target the right audience.</li>
                        <li>SEO-optimized content that boosts visibility and engagement.</li>
                        <li>On-page optimization that strengthens overall search performance.</li>
                        <li>Content audits that refine and improve existing pages.</li>
                        <li>Internal linking that enhances navigation and authority flow.</li>
                        <li>Performance tracking that guides ongoing content improvements.</li>

                    </ul>
                </div>
                <!-- <div class="services-panel">
                            <div class="services-panel-inner">
                                <p class="services-label">Editorial Overview Panel</p>
                                <p class="services-text">
                                    A clear view of your current content inventory, performance and opportunities.
                                </p>
                                <p class="services-meta">
                                    Ideal for marketing teams that need a structured editorial roadmap aligned with SEO goals.
                                </p>
                            </div>
                        </div> -->
            </div>
        </div>
    </section>

    <!-- PROCESS -->
    <section class="section section-process" style="margin-top:35px" id="process">
        <div class="container">
            <div class="section-header section-header-light">
                <h2>Our Content SEO Process</h2>
                <p>
                    A streamlined, data-driven approach that optimizes your content for visibility, relevance, and results.
                </p>
            </div>

            <div class="grid grid-4 process-grid">
                <article class="card process-card">
                    <div class="process-icon"></div>
                    <h3>Research &amp; Analysis</h3>
                    <p>
                        We identify keywords, audiences, and opportunities to guide your strategy.
                    </p>
                </article>

                <article class="card process-card">
                    <div class="process-icon"></div>
                    <h3>Content Creation</h3>
                    <p>
                        We produce high-quality, SEO-focused content tailored to user intent.
                    </p>
                </article>

                <article class="card process-card">
                    <div class="process-icon"></div>
                    <h3>Optimisation</h3>
                    <p>
                        We refine on-page elements to improve visibility and search performance.
                    </p>
                </article>

                <article class="card process-card">
                    <div class="process-icon"></div>
                    <h3>Performance Tracking</h3>
                    <p>
                        We monitor rankings and engagement to guide ongoing improvements.
                    </p>
                </article>
            </div>
        </div>
    </section>

    <!-- CTA -->
    <section class="section content-cta" style="margin-top:35px" id="cta">
        <div class="container">
            <div class="cta-inner content-cta-inner">
                <div class="cta-main">
                    <h2>Ready to Grow with Content?</h2>
                    <p>
                        Let our content SEO specialists create and optimise content that ranks, engages and converts.
                    </p>
                </div>
                <div class="cta-actions content-cta-actions">
                    <a href="#contact-form" class="btn btn-primary">Request Content Audit</a>
                    <a href="#types" class="btn btn-outline-light">Explore Content Types</a>
                </div>
            </div>
        </div>
    </section>

    <!-- CONTACT FORM -->
    <section class="section section-contact" id="contact-form">
        <div class="container">
            <div class="section-header">
                <h2>Talk to Our Content SEO Team</h2>
                <p>
                    Share a few details and we&apos;ll propose a tailored content SEO strategy for your business.
                </p>
            </div>

            <form class="contact-form" method="POST" action="{{ route('contact.submit') }}">
                @csrf

                {{-- Identifiers --}}
                <input type="hidden" name="form_key" value="seo_content_enquiry">
                <input type="hidden" name="source_page" value="{{ request()->path() }}">

                <div class="form-row">
                    <div class="form-field">
                        <label for="seo_content_name">Full Name</label>
                        <input type="text" id="seo_content_name" name="name" placeholder="Enter your name"
                            required>
                    </div>

                    <div class="form-field">
                        <label for="seo_content_email">Email Address</label>
                        <input type="email" id="seo_content_email" name="email" placeholder="name@company.com"
                            required>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-field">
                        <label for="seo_content_website">Website URL</label>
                        <input type="url" id="seo_content_website" name="payload[website]" placeholder="https://">
                    </div>

                    <div class="form-field">
                        <label for="seo_content_focus">Main Content Focus</label>
                        <input type="text" id="seo_content_focus" name="payload[content_focus]"
                            placeholder="Blogs, product pages, landing pages, etc.">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-field form-field-full">
                        <label for="seo_content_message">What are your content goals?</label>
                        <textarea id="seo_content_message" name="message" rows="4"
                            placeholder="More traffic, better rankings, higher conversions, etc." required></textarea>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Submit Enquiry</button>
            </form>
        </div>
    </section>



    <!-- FAQ -->
    <section class="section section-alt section-faq" id="faq">
        <div class="container">
            <div class="section-header">
                <h2>Content SEO FAQs</h2>
            </div>

            <div class="faq-wrap">
                <div class="faq-list">
                    <details class="faq-item">
                        <summary>1. What is Content SEO Service?</summary>
                        <div class="faq-content">
                            <p>
                                Content SEO Services focus on creating and optimizing content so it can rank higher, attract
                                organic traffic, and improve your brand’s authority.
                            </p>
                        </div>
                    </details>

                    <details class="faq-item">
                        <summary>2. Why Is Content SEO Important for My Business?</summary>
                        <div class="faq-content">
                            <p>
                                Content SEO helps increase visibility, drive qualified traffic, and build trust with your
                                audience through valuable, optimized content.
                            </p>
                        </div>
                    </details>

                    <details class="faq-item">
                        <summary>3. What Types of Content Do You Optimize?</summary>
                        <div class="faq-content">
                            <p>
                                We optimize blog posts, landing pages, product descriptions, technical content, and website
                                copy to improve search performance.
                            </p>
                        </div>
                    </details>

                    <details class="faq-item">
                        <summary>4.How Do You Improve Content Rankings?</summary>
                        <div class="faq-content">
                            <p>
                                We use keyword research, on-page optimization, internal linking, meta improvements, and
                                content enhancements to boost rankings.
                            </p>
                        </div>
                    </details>

                    <details class="faq-item">
                        <summary>5. What Is Included in Your Content SEO Process?</summary>
                        <div class="faq-content">
                            <p>Our process includes research & analysis, content creation, optimization, and performance
                                tracking for continuous improvement.
                            </p>
                        </div>
                    </details>

                    <details class="faq-item">
                        <summary>6. Do technical fixes improve rankings?</summary>
                        <div class="faq-content">
                            <p>
                                Content SEO typically shows measurable improvements within 2–3 months, with stronger
                                long-term growth over time.</p>
                        </div>
                    </details>
                </div>
            </div>
        </div>
    </section>

@endsection
