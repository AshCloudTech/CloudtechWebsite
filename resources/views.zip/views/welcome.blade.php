@extends('layouts.cloudtech')

@section('title', 'Digital Marketing, SEO & Web Development Company UK')
@section('meta_title', 'Digital Marketing, SEO & Web Development Company UK')
@section('meta_description', 'Looking to grow your business online? Our UK team offers SEO, web development and digital
    marketing to bring more traffic, leads and sales for business growth!')
@section('meta_keywords', 'digital marketing, SEO, web development, UK, business growth, online marketing, search engine optimization, website design, digital solutions')
    @push('styles')
        <link rel="stylesheet" href="{{ asset('assets/cloud-home/css/style.css') }}">
    @endpush
    @push('scripts')
        <script src="{{ asset('assets/cloud-home/js/script.js') }}" defer></script>
    @endpush

@section('content')

    <!-- HERO -->
    <section class="hero" id="hero" style="min-height: 550px;">
        <div class="hero-bg"></div>
        <div class="hero-overlay"></div>
        <div class="container hero-content">
            <div class="hero-text">
                <p class="hero-eyebrow">Smart Digital Solutions for Growth & Performance</p>
                <h1>Build. Grow. Transform.</h1>
                <p class="hero-subtitle">
                    All-in-one hub for digital, design, and AI solutions.
                </p>

                <div class="hero-actions">
                    <a href="#services" class="btn btn-lg btn-primary">Explore Services</a>
                    {{-- <a href="#ai-innovation" class="btn btn-lg btn-ghost">Chat with AI Assistant</a> --}}
                    <a href="#consultation" class="btn btn-lg btn-ghost openConsultationModal">Schedule a Consultation</a>
                </div>

                {{-- <p class="hero-note">
                    Delivering powerful cloud technology that helps entrepreneurs scale faster, <br> reach global markets
                    and achieve real results.
                </p> --}}
            </div>

            <div class="hero-stats">
                <div class="stat-card">
                    <span class="stat-value">200+</span>
                    <span class="stat-label">Projects Delivered</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">£1.3M+</span>
                    <span class="stat-label">Project Value Delivered</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">UK • UAE • India</span>
                    <span class="stat-label">Countries Served</span>
                </div>
                <div class="stat-card">
                    <span class="stat-value">98%</span>
                    <span class="stat-label">Client Satisfaction</span>
                </div>
            </div>
        </div>
    </section>

    <!-- SERVICES -->
    <section class="section" id="services">
        <div class="container">
            <div class="section-header">
                <h2>Our Digital Services</h2>
                <p>
                    We deliver complete digital solutions including marketing, design, development, branding, SEO and
                    product growth to elevate your business online.
                </p>
            </div>

            <div class="grid grid-3 services-grid">
                <!-- Digital Marketing -->
                <article class="card service-card">
                    <div class="card-tag tag-blue">Digital Marketing</div>
                    <a href="{{ route('services.digital.marketing') }}">
                        <img src="{{ asset('assets/images/home/digital_marketing.webp') }}" class="service-image"
                            alt="Digital Marketing" title="Digital Marketing" aria-label="Digital Marketing"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.digital.marketing') }}">Digital Marketing</a></h3>
                    <p>Digital marketing solutions designed to boost visibility and drive sales.</p>
                    <ul class="service-list">
                        <li>Social Media Marketing</li>
                        <li>PPC Advertising</li>
                        <li>Email Marketing</li>
                        <li>Content Strategy</li>
                    </ul>
                </article>

                <!-- UI/UX Design -->
                <article class="card service-card">
                    <div class="card-tag tag-purple">UI/UX Design</div>
                    <a href="{{ route('services.uiux') }}">
                        <img src="{{ asset('assets/images/home/ui_&_ux_design.webp') }}" class="service-image"
                            alt="UI/UX Design" title="UI/UX Design" aria-label="UI/UX Design" aria-hidden="true"
                            loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.uiux') }}">UI/UX Design</a></h3>
                    <p>End-to-end UI/UX design that aligns business goals with user needs.</p>
                    <ul class="service-list">
                        <li>User Research</li>
                        <li>Wireframing</li>
                        <li>Prototyping</li>
                        <li>Usability Testing</li>
                    </ul>
                </article>

                <!-- Web Development -->
                <article class="card service-card">
                    <div class="card-tag tag-green">Web Development</div>
                    <a href="{{ route('services.web.development') }}">
                        <img src="{{ asset('assets/images/home/web_development.webp') }}" class="service-image"
                            alt="Web Development" title="Web Development" aria-label="Web Development" aria-hidden="true"
                            loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.web.development') }}">Web Development</a></h3>
                    <p>Fast, responsive websites developed for seamless user experiences.</p>
                    <ul class="service-list">
                        <li>Responsive Design</li>
                        <li>CMS Integration</li>
                        <li>E-commerce</li>
                        <li>Performance Optimization</li>
                    </ul>
                </article>

                <!-- Branding -->
                <article class="card service-card">
                    <div class="card-tag tag-orange">Branding</div>
                    <a href="{{ route('services.branding') }}">
                        <img src="{{ asset('assets/images/home/branding.webp') }}" class="service-image" alt="Branding"
                            title="Branding" aria-label="Branding" aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.branding') }}">Branding</a></h3>
                    <p>Bold branding that captures attention and elevates your presence.</p>
                    <ul class="service-list">
                        <li>Logo Design</li>
                        <li>Brand Guidelines</li>
                        <li>Visual Identity</li>
                        <li>Brand Strategy</li>
                    </ul>
                </article>

                <!-- SEO -->
                <article class="card service-card">
                    <div class="card-tag tag-teal">SEO</div>
                    <a href="{{ route('services.seo') }}">
                        <img src="{{ asset('assets/images/home/seo.webp') }}" class="service-image" alt="SEO"
                            title="SEO" aria-label="SEO" aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.seo') }}">SEO</a></h3>
                    <p>Powerful SEO that improves rankings, traffic, and conversions.</p>
                    <ul class="service-list">
                        <li>Local SEO</li>
                        <li>Regional SEO</li>
                        <li>National SEO</li>
                        <li>International SEO</li>
                    </ul>
                </article>

                <!-- Product Marketing -->
                <article class="card service-card">
                    <div class="card-tag tag-pink">Product Marketing</div>
                    <a href="{{ route('services.product.marketing') }}">
                        <img src="{{ asset('assets/images/home/product_marketing.webp') }}" class="service-image"
                            alt="Product Marketing" title="Product Marketing" aria-label="Product Marketing"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('services.product.marketing') }}">Product Marketing</a></h3>
                    <p>Complete product marketing solutions designed to maximize product success.</p>
                    <ul class="service-list">
                        <li>Go-to-Market Strategy</li>
                        <li>Product Positioning</li>
                        <li>Launch Campaigns</li>
                        <li>Growth Marketing</li>
                    </ul>
                </article>
            </div>
        </div>
    </section>

    <!-- PROCESS -->
    {{-- <section class="section section-alt" id="about">
        <div class="container">
            <div class="section-header">
                <h2>Our Design &amp; Development Process</h2>
                <p>
                    Our design and development process blends creativity, strategy, and precision to turn ideas into
                    polished, high-performing digital experiences.
                </p>
            </div>

            <div class="grid grid-4 process-grid">
                <article class="card process-card">
                    <div class="process-step">01</div>
                    <h3>Discovery &amp; Research</h3>
                    <p>
                        We uncover insights, analyze user needs, and gather essential data to build a strong foundation for
                        your project. </p>
                </article>

                <article class="card process-card">
                    <div class="process-step">02</div>
                    <h3>Strategy &amp; Planning</h3>
                    <p>
                        We translate insights into a clear roadmap, aligning goals, timelines, and resources to ensure a
                        successful project outcome. </p>
                </article>

                <article class="card process-card">
                    <div class="process-step">03</div>
                    <h3>Design &amp; Development</h3>
                    <p>
                        Designing with intent and developing with precision to deliver results that are both functional and
                        impactful. </p>
                </article>

                <article class="card process-card">
                    <div class="process-step">04</div>
                    <h3>Launch &amp; Optimize</h3>
                    <p>
                        We launch your project, monitor results, and make improvements to keep everything running smoothly.
                    </p>
                </article>
            </div>
        </div>
    </section> --}}

    {{-- Updated DESIGN & DEVELOPMENT PROCESS --}}
    <section class="section process-section" id="process">
        <div class="container">
            <div class="section-header">
                <h2>Our Design &amp; Development Process</h2>
                <p>A proven methodology that ensures exceptional results from concept to launch and beyond.</p>
            </div>

            <div class="process-grid">
                <article class="process-item">
                    <div class="process-icon" aria-hidden="true">
                        {{-- Search icon --}}
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M10.5 3a7.5 7.5 0 1 0 4.6 13.4l4.3 4.3a1 1 0 0 0 1.4-1.4l-4.3-4.3A7.5 7.5 0 0 0 10.5 3zm0 2a5.5 5.5 0 1 1 0 11a5.5 5.5 0 0 1 0-11z" />
                        </svg>
                    </div>

                    <h3>Discovery &amp; Research</h3>
                    <p>We start by understanding your business goals, target audience, and competitive landscape.</p>
                </article>

                <article class="process-item">
                    <div class="process-icon" aria-hidden="true">
                        {{-- Bulb icon --}}
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M9 21h6v-1H9v1zm3-19a7 7 0 0 0-4 12.7V17a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1v-2.3A7 7 0 0 0 12 2zm3 11.6a1 1 0 0 0-.4.8V16h-5.2v-1.6a1 1 0 0 0-.4-.8A5 5 0 1 1 15 13.6z" />
                        </svg>
                    </div>

                    <h3>Strategy &amp; Planning</h3>
                    <p>Develop a comprehensive digital strategy tailored to your specific needs and objectives.</p>
                </article>

                <article class="process-item">
                    <div class="process-icon" aria-hidden="true">
                        {{-- Code icon --}}
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M8.7 16.7a1 1 0 0 1-1.4 0l-4-4a1 1 0 0 1 0-1.4l4-4a1 1 0 1 1 1.4 1.4L5.4 12l3.3 3.3a1 1 0 0 1 0 1.4zm6.6 0a1 1 0 0 0 1.4 0l4-4a1 1 0 0 0 0-1.4l-4-4a1 1 0 1 0-1.4 1.4L18.6 12l-3.3 3.3a1 1 0 0 0 0 1.4zM13.6 5.3a1 1 0 0 0-1.9-.6l-3.3 14a1 1 0 1 0 1.9.6l3.3-14z" />
                        </svg>
                    </div>

                    <h3>Design &amp; Development</h3>
                    <p>Create stunning designs and develop robust solutions using cutting-edge technologies.</p>
                </article>

                <article class="process-item">
                    <div class="process-icon" aria-hidden="true">
                        {{-- Bell icon --}}
                        <svg viewBox="0 0 24 24">
                            <path
                                d="M12 22a2.5 2.5 0 0 0 2.45-2h-4.9A2.5 2.5 0 0 0 12 22zm7-6V11a7 7 0 1 0-14 0v5l-2 2v1h18v-1l-2-2zm-2 1H7l1-1v-5a5 5 0 1 1 10 0v5l1 1z" />
                        </svg>
                    </div>

                    <h3>Launch &amp; Optimize</h3>
                    <p>Deploy your solution and continuously optimize for better performance and results.</p>
                </article>
            </div>
        </div>
    </section>

    <!-- INDUSTRIES -->
    <section class="section" id="industries">
        <div class="container">
            <div class="section-header">
                <h2>Industries We Serve</h2>
                <p>
                    We work with businesses in many sectors, providing solutions that fit their goals and audiences. </p>
            </div>

            <div class="grid grid-3 industries-grid">
                <!-- Healthcare -->
                <article class="card industry-card">
                    <div class="card-tag tag-blue">Healthcare Solutions</div>
                    <a href="{{ route('industries.cloudhealth') }}">
                        <img src="{{ asset('assets/images/home/healthcare_solutions.webp') }}" class="industry-image"
                            alt="Healthcare Solutions" title="Healthcare Solutions" aria-label="Healthcare Solutions"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudhealth') }}">Healthcare Solutions</a></h3>
                    <p>
                        Complete digital tools for healthcare providers, offering easy appointment scheduling and efficient
                        patient management in one platform.
                    </p>
                    <a href="{{ route('industries.cloudhealth') }}" class="link-arrow">Learn More</a>
                </article>

                <!-- Care Dashboard -->
                <article class="card industry-card">
                    <div class="card-tag tag-purple">Care Dashboard Management</div>
                    <a href="{{ route('industries.cloudcare') }}">
                        <img src="{{ asset('assets/images/home/care_dashboard_management.webp') }}"
                            class="industry-image" alt="Care Dashboard Management" title="Care Dashboard Management"
                            aria-label="Care Dashboard Management" aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudcare') }}">Care Dashboard Management</a></h3>
                    <p>
                        Digital solutions for care homes that include CQC-ready websites, easy resident management, and
                        flexible subscription models to support growth.
                    </p>
                    <a href="{{ route('industries.cloudcare') }}" class="link-arrow">Learn More</a>
                </article>

                <!-- Education -->
                <article class="card industry-card">
                    <div class="card-tag tag-green">Education Technology</div>
                    <a href="{{ route('industries.cloudedu') }}">
                        <img src="{{ asset('assets/images/home/education_technology.webp') }}" class="industry-image"
                            alt="Education Technology" title="Education Technology" aria-label="Education Technology"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudedu') }}">Education Technology</a></h3>
                    <p>
                        End-to-end school digitalization solutions featuring admission CRM, parent communication apps, and
                        fully integrated educational management systems.
                    </p>
                    <a href="{{ route('industries.cloudedu') }}" class="link-arrow">Learn More</a>
                </article>

                <!-- Travel -->
                <article class="card industry-card">
                    <div class="card-tag tag-orange">Travel &amp; Tourism</div>
                    <a href="{{ route('industries.cloudtravel') }}">
                        <img src="{{ asset('assets/images/home/travel_&_tourism.webp') }}" class="industry-image"
                            alt="Travel & Tourism" title="Travel & Tourism" aria-label="Travel & Tourism"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudtravel') }}">Travel &amp; Tourism</a></h3>
                    <p>
                        Travel solutions with real-time Expedia and Viator integrations, easy booking tools, and full travel
                        management features.
                    </p>
                    <a href="{{ route('industries.cloudtravel') }}" class="link-arrow">Learn More</a>
                </article>

                <!-- Recruitment -->
                <article class="card industry-card">
                    <div class="card-tag tag-teal">Recruitment Solutions</div>
                    <a href="{{ route('industries.cloudrecruit') }}">
                        <img src="{{ asset('assets/images/home/recruitment_solutions.webp') }}" class="industry-image"
                            alt="Recruitment Solutions" title="Recruitment Solutions" aria-label="Recruitment Solutions"
                            aria-hidden="true" loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudrecruit') }}">Recruitment Solutions</a></h3>
                    <p>
                        AI-enhanced recruitment systems combining powerful ATS, intelligent CRM workflows, and automated
                        shortlisting to source and place talent worldwide.
                    </p>
                    <a href="{{ route('industries.cloudrecruit') }}" class="link-arrow">Learn More</a>
                </article>

                <!-- Public Sector -->
                <article class="card industry-card">
                    <div class="card-tag tag-pink">Public Sector</div>
                    <a href="{{ route('industries.cloudpublic') }}">
                        <img src="{{ asset('assets/images/home/public_sector.webp') }}" class="industry-image"
                            alt="Public Sector" title="Public Sector" aria-label="Public Sector" aria-hidden="true"
                            loading="lazy" decoding="async">
                    </a>
                    <h3><a href="{{ route('industries.cloudpublic') }}">Public Sector</a></h3>
                    <p>
                        Specialized public-sector platforms that streamline governance, enhance QA processes, and support
                        efficient delivery management for UK organizations.
                    </p>
                    <a href="{{ route('industries.cloudpublic') }}" class="link-arrow">Learn More</a>
                </article>
            </div>
        </div>
    </section>

    <!-- AI INNOVATION -->
    <section class="section section-alt" id="ai-innovation">
        <div class="container">
            <div class="section-header">
                <h2>AI Powered Innovation</h2>
                <p>
                    Next-generation AI innovations that help organizations stay ahead with smarter automation, predictive
                    intelligence, and adaptive learning models.
                </p>
            </div>

            <div class="grid grid-3 ai-grid">
                <article class="card ai-card">
                    <div class="card-tag tag-blue">AI Chatbot Assistant</div>
                    <img src="{{ asset('assets/images/home/ai_chatbot_assistant.webp') }}" class="service-image"
                        alt="AI Chatbot Assistant" title="AI Chatbot Assistant" aria-label="AI Chatbot Assistant"
                        aria-hidden="true" loading="lazy" decoding="async">


                    <h3>AI Chatbot Assistant</h3>
                    <p>
                        A powerful AI-driven chatbot that automates customer queries, streamlines appointment booking, and
                        provides round-the-clock service across web and mobile.
                    </p>
                </article>

                <article class="card ai-card">
                    <div class="card-tag tag-purple">AI Recruiter</div>
                    <img src="{{ asset('assets/images/home/ai_recruiter.webp') }}" class="service-image"
                        alt="AI Recruiter" title="AI Recruiter" aria-label="AI Recruiter" aria-hidden="true"
                        loading="lazy" decoding="async">


                    <h3>AI Recruiter</h3>
                    <p>
                        AI-driven recruitment technology that automates candidate screening, interview scheduling, and
                        talent matching through powerful machine-learning insights.
                    </p>
                </article>

                <article class="card ai-card">
                    <div class="card-tag tag-green">AI Itinerary Builder</div>
                    <img src="{{ asset('assets/images/home/ai_itinerary_builder.webp') }}" class="service-image"
                        alt="AI Itinerary Builder" title="AI Itinerary Builder" aria-label="AI Itinerary Builder"
                        aria-hidden="true" loading="lazy" decoding="async">

                    <h3>AI Itinerary Builder</h3>
                    <p>
                        AI-powered itinerary technology that customizes travel plans, curates destination ideas, and adjusts
                        routes dynamically with real-time insights.
                    </p>
                </article>

                <article class="card ai-card">
                    <div class="card-tag tag-orange">AI Healthcare Assistant</div>

                    <img src="{{ asset('assets/images/home/ai_healthcare_assistant.webp') }}" class="service-image"
                        alt="AI Healthcare Assistant" title="AI Healthcare Assistant"
                        aria-label="AI Healthcare Assistant" aria-hidden="true" loading="lazy" decoding="async">
                    <h3>AI Healthcare Assistant</h3>
                    <p>
                        AI-powered healthcare support that automates appointment booking, analyzes symptoms, and offers
                        accurate medical guidance with strict HIPAA-compliant data protection.
                    </p>
                </article>

                <article class="card ai-card">
                    <div class="card-tag tag-teal">AI Learning Platform</div>
                    <img src="{{ asset('assets/images/home/ai_learning_platform.webp') }}" class="service-image"
                        alt="AI Learning Platform" title="AI Learning Platform" aria-label="AI Learning Platform"
                        aria-hidden="true" loading="lazy" decoding="async">
                    <h3>AI Learning Platform</h3>
                    <p>
                        An AI-driven learning platform that personalizes lessons, tracks student progress, and delivers
                        intelligent tutoring to improve educational outcomes.
                    </p>
                </article>

                <article class="card ai-card">
                    <div class="card-tag tag-pink">AI Care Coordinator</div>
                    <img src="{{ asset('assets/images/home/ai_care_coordinator.webp') }}" class="service-image"
                        alt="AI Care Coordinator" title="AI Care Coordinator" aria-label="AI Care Coordinator"
                        aria-hidden="true" loading="lazy" decoding="async">
                    <h3>AI Care Coordinator</h3>
                    <p>
                        AI-powered care coordination that centralizes resident care plans, supports medication management,
                        and enhances family engagement with CQC-aligned processes.
                    </p>
                </article>
            </div>

            <div class="ai-cta">
                <h3>Ready to Transform Your Business with AI?</h3>
                <p>
                    Empower your business with intelligent automation, predictive insights, and next-generation AI
                    capabilities.
                </p>
                <div class="ai-cta-actions">
                    <a href="#consultation" class="btn btn-primary openConsultationModal">Schedule Consultation</a>
                    <a href="#case-studies" class="btn btn-ghost">View AI Case Studies</a>
                </div>
            </div>
        </div>
    </section>

    <!-- PRICING -->
    <section class="section" id="pricing">
        <div class="container">
            <div class="section-header">
                <h2>Choose Your Plan</h2>
                <p>Pick the ideal plan to scale your business with the right tools and support.</p>
            </div>

            <div class="grid grid-3 pricing-grid">
                @forelse($featuredPlans as $plan)
                    @php
                        $price = $plan->priceByBilling('one-time');
                    @endphp

                    <article class="card pricing-card {{ $plan->is_featured ? 'pricing-popular' : '' }}">
                        @if ($plan->is_featured)
                            <div class="pricing-badge">Most Popular</div>
                        @endif

                        <h3>{{ $plan->title }}</h3>

                        <p class="pricing-price">
                            {{ $price?->currency }}{{ $price?->amount_text }}
                            <span>/one-time</span>
                        </p>

                        @if ($plan->description)
                            <p class="pricing-subtitle">{{ $plan->description }}</p>
                        @endif

                        <ul class="pricing-list">
                            @foreach ($plan->features->take(8) as $feature)
                                <li>{{ $feature->text }}</li>
                            @endforeach
                        </ul>

                        <a href="{{ url($plan->cta_url) }}" class="btn btn-primary btn-block">
                            {{ $plan->cta_text }}
                        </a>
                    </article>
                @empty
                    <p>No featured plans available.</p>
                @endforelse
            </div>

            <div style="margin-top:32px; display:flex; justify-content:center;">
                <a href="{{ route('pricing') }}" class="btn btn-ghost">
                    View All Plans
                </a>
            </div>
        </div>
    </section>

    {{-- CTA + FORM (REPLACES OLD CONTACT-FORM SECTION) --}}
    <section class="section cta-section" id="contact-form">
        <div class="container">
            <div class="cta-grid">
                {{-- Left Content --}}
                <div class="cta-left">
                    <span class="cta-pill">Start Your Journey</span>

                    <h2 class="cta-title">Let’s Build Something<br />Amazing Together</h2>

                    <p class="cta-subtitle">
                        Ready to transform your digital presence? Share your project details with us, and our expert team
                        will
                        get back to you within 24 hours with a customized solution.
                    </p>

                    <div class="cta-stats" aria-label="Company highlights">
                        <div class="cta-stat">
                            <div class="cta-stat__value">100 +</div>
                            <div class="cta-stat__label">Happy Clients</div>
                        </div>

                        <div class="cta-stat">
                            <div class="cta-stat__value">99%</div>
                            <div class="cta-stat__label">Satisfaction</div>
                        </div>

                        <div class="cta-stat">
                            <div class="cta-stat__value">24/7</div>
                            <div class="cta-stat__label">Support</div>
                        </div>
                    </div>
                </div>

                {{-- Right Form Card --}}
                <div class="cta-card">
                    <h3 class="cta-card__title">Get Started Today</h3>
                    <p class="cta-card__desc">Fill out the form below and our team will reach out to you.</p>

                    <form class="cta-form" method="POST"
                        action="{{ Route::has('contact.send') ? route('contact.send') : (Route::has('contact.submit') ? route('contact.submit') : url('/contact')) }}"
                        novalidate>
                        @csrf

                        <input type="hidden" name="form_key" value="home_cta_form">
                        <input type="hidden" name="source_page" value="{{ request()->path() }}">

                        <div class="cta-field">
                            <label for="cta_full_name">Full Name</label>
                            <input id="cta_full_name" type="text" name="name" placeholder="John Doe"
                                value="{{ old('name') }}" />
                            @error('name')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <div class="cta-field">
                            <label for="cta_email">Email Address</label>
                            <input id="cta_email" type="email" name="email" placeholder="john@example.com"
                                value="{{ old('email') }}" />
                            @error('email')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <div class="cta-field">
                            <label for="cta_phone">Phone Number</label>
                            <input id="cta_phone" type="text" name="phone" placeholder="+44 20 1223-4567"
                                value="{{ old('phone') }}" />
                        </div>

                        <div class="cta-field">
                            <label for="cta_company">Company/Website Url</label>
                            <input id="website" name="website" type="text" placeholder="https://example.com"
                                autocomplete="url">
                        </div>

                        <div class="cta-field">
                            <label for="cta_service">Service Interested In <span class="cta-required">*</span></label>
                            <select id="cta_service" name="service" required>
                                <option value="" selected disabled>Select a service</option>
                                <option value="Website Development" @selected(old('service') === 'Website Development')>Website
                                    Development</option>
                                <option value="SEO" @selected(old('service') === 'SEO')>SEO</option>
                                <option value="Branding" @selected(old('service') === 'Branding')>Branding</option>
                                <option value="Mobile App Development" @selected(old('service') === 'Mobile App Development')>Mobile App Development
                                </option>
                                <option value="E-commerce" @selected(old('service') === 'E-commerce')>E-commerce</option>
                            </select>
                            @error('service')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <div class="cta-field">
                            <label for="cta_message">Project Details</label>
                            <textarea id="cta_message" name="message" rows="3" placeholder="Tell us about your project requirements...">{{ old('message') }}</textarea>
                            @error('message')
                                <small class="text-danger">{{ $message }}</small>
                            @enderror
                        </div>

                        <button type="submit" class="btn btn-primary cta-submit">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- CASE STUDIES -->
    <section class="section section-alt" id="case-studies">
        <div class="container">
            <div class="section-header">
                <h2>Case Studies</h2>
                <p>
                    See how our strategies and solutions have helped clients achieve outstanding outcomes.
                </p>
            </div>

            <div class="grid grid-2 case-grid">
                @forelse($caseStudies as $case)
                    @php
                        // Tag color class from DB (fallback safe)
                        $tagClass = match ($case->industry_tag_color) {
                            'purple' => 'tag-purple',
                            'green' => 'tag-green',
                            'orange' => 'tag-orange',
                            default => 'tag-blue',
                        };

                        // Pick image (prefer card_image, fallback to hero_image)
                        $imgPath = $case->card_image ?: $case->hero_image;
                        $imgUrl = $imgPath ? (str_starts_with($imgPath, 'http') ? $imgPath : asset($imgPath)) : null;

                        $imgAlt = $case->title ? $case->title . ' case study' : 'Case study image';
                    @endphp

                    <article class="card case-card fx-reveal">


                        <div class="case-body">
                            {{-- Industry tag --}}
                            @if ($case->industry)
                                <div class="card-tag {{ $tagClass }}">
                                    {{ $case->industry }}
                                </div>
                            @endif
                            {{-- Image --}}
                            @if ($imgUrl)
                                <a href="{{ route('case.studies.detail', $case->slug) }}" class="case-thumb"
                                    aria-label="Open {{ $case->title }}">
                                    <img src="{{ $imgUrl }}" alt="{{ $imgAlt }}" loading="lazy"
                                        decoding="async">
                                </a>
                            @else
                                {{-- Optional: placeholder if no image --}}
                                <div class="case-thumb case-thumb--placeholder" aria-hidden="true"></div>
                            @endif
                            {{-- Title --}}
                            <h3>{{ $case->title }}</h3>

                            {{-- Short description --}}
                            @if ($case->excerpt)
                                <p>{{ $case->excerpt }}</p>
                            @endif

                            {{-- Impact metrics --}}
                            @if ($case->impacts->count())
                                <ul class="case-results">
                                    @foreach ($case->impacts->take(3) as $impact)
                                        <li>
                                            @if ($impact->metric)
                                                <strong>{{ $impact->metric }}</strong>
                                            @endif
                                            {{ $impact->title }}
                                        </li>
                                    @endforeach
                                </ul>
                            @endif

                            {{-- Tech stack --}}
                            @if ($case->techStacks->count())
                                <p class="case-stack">
                                    <strong>Technologies Used:</strong>
                                    {{ $case->techStacks->pluck('name')->implode(', ') }}
                                </p>
                            @endif

                            {{-- Link --}}
                            <a href="{{ route('case.studies.detail', $case->slug) }}" class="link-arrow">
                                Read Full Case Study
                            </a>
                        </div>
                    </article>

                @empty
                    <div class="card" style="padding:18px;">
                        <p style="margin:0;">No case studies available right now.</p>
                    </div>
                @endforelse
            </div>

            <div class="case-footer">
                <a href="{{ route('case.studies') }}" class="btn btn-ghost">
                    View All Case Studies
                </a>
            </div>
        </div>
    </section>

    <!-- GLOBAL PRESENCE -->
    {{-- <section class="section global-section" id="portfolio">
        <div class="global-bg"></div>
        <div class="container">
            <div class="section-header">
                <h2>Global Presence</h2>
                <p>
                    With offices in the UK, UAE, and India and a registered entity in the United States, we support clients across regions and time zones. </p>
            </div>

            <div class="grid grid-4 global-grid">
                <article class="card global-card">
                    <h3>United Kingdom</h3>
                    <p>Headquarters &amp; Primary Operations</p>
                    <ul>
                        <li>England</li>
                        <li>Scotland</li>
                        <li>Wales</li>
                        <li>Northern Ireland</li>
                    </ul>
                </article>

                <article class="card global-card">
                    <h3>Europe</h3>
                    <p>European Union &amp; Associated States</p>
                    <ul>
                        <li>Germany</li>
                        <li>France</li>
                        <li>Netherlands</li>
                        <li>Spain</li>
                        <li>Italy</li>
                        <li>Poland</li>
                    </ul>
                </article>

                <article class="card global-card">
                    <h3>North America</h3>
                    <p>United States &amp; Canada</p>
                    <ul>
                        <li>United States</li>
                        <li>Canada</li>
                    </ul>
                </article>

                <article class="card global-card">
                    <h3>Asia Pacific</h3>
                    <p>Growing Markets &amp; Innovation Hubs</p>
                    <ul>
                        <li>Australia</li>
                        <li>Singapore</li>
                        <li>Japan</li>
                        <li>India</li>
                        <li>New Zealand</li>
                    </ul>
                </article>

                <article class="card global-card">
                    <h3>Middle East &amp; Africa</h3>
                    <p>Emerging Digital Markets</p>
                    <ul>
                        <li>UAE</li>
                        <li>South Africa</li>
                        <li>Nigeria</li>
                        <li>Kenya</li>
                    </ul>
                </article>

                <article class="card global-metrics">
                    <div class="metric">
                        <span class="metric-value">25+</span>
                        <span class="metric-label">Countries</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value">50+</span>
                        <span class="metric-label">Cities</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value">12</span>
                        <span class="metric-label">Time Zones</span>
                    </div>
                    <div class="metric">
                        <span class="metric-value">24/7</span>
                        <span class="metric-label">Support</span>
                    </div>
                </article>
            </div>
        </div>
    </section> --}}
    @php
        $branches = ($company?->branches ?? collect())->where('is_active', true)->sortBy('sort_order')->values();

        $mapCountryCodes = $branches
            ->pluck('country_code')
            ->filter()
            ->map(fn($c) => strtoupper(trim($c)))
            ->unique()
            ->values();

        $mapBranches = $branches
            ->map(function ($b) {
                return [
                    'id' => (int) $b->id,
                    'name' => (string) ($b->name ?? ''),
                    'code' => (string) ($b->code ?? ''),
                    'city' => (string) ($b->city ?? ''),
                    'country_code' => strtoupper(trim((string) ($b->country_code ?? ''))),
                    'lat' => $b->latitude !== null ? (float) $b->latitude : null,
                    'lon' => $b->longitude !== null ? (float) $b->longitude : null,
                    'is_hq' => (bool) $b->is_hq,
                ];
            })
            ->values();
    @endphp

    <section class="worldMap" id="worldMap">
        <div class="worldMap__container">
            <div class="section-header">
                <h2>Global Presence</h2>
                <p>
                    With offices in the UK, UAE, and India and a registered entity in the United States, we support clients
                    across regions and time zones. </p>
            </div>

            <div class="worldMap__right">
                <div class="worldMap__svgWrap">
                    <figure class="worldMap__figure">
                        @include('partials.world-map-svg')

                        <figcaption class="sr-only" id="worldMapCaption">
                            World map showing branch locations.
                        </figcaption>

                        <div class="worldMap__tooltip" id="mapTooltip" role="status" aria-live="polite"></div>
                    </figure>
                </div>

            </div>
        </div>

        <script>
            window.WORLD_MAP_COUNTRY_CODES = @js($mapCountryCodes);
            window.WORLD_MAP_BRANCHES = @js($mapBranches);
        </script>
    </section>
    @push('styles')
        <link rel="stylesheet" href="{{ asset('assets/world-map.css') }}">
    @endpush
    @push('scripts')
        <script src="{{ asset('assets/world-map.js') }}" defer></script>
    @endpush


    <!-- CTA SECTION -->
    <section class="section cta-sectionconsult" id="contact">
        <div class="container">
            <div class="cta-inner">
                <div class="cta-main">
                    <h2>Start Your Digital Transformation Journey Today</h2>
                    <p>
                        Join hundreds of organizations worldwide who have transformed their operations with our
                        British-built digital solutions. Let’s discuss how we can accelerate your digital transformation.
                    </p>
                    <div class="cta-actions">
                        <a href="#contact-form" class="btn btn-primary openConsultationModal">Book Free Consultation</a>
                        <!-- <a href="#hero" class="btn btn-ghost">Chat with AI Assistant</a> -->
                    </div>
                </div>
                <div class="cta-steps">
                    <div class="cta-step">
                        <h3>Free Consultation</h3>
                        <p>30-minute strategy session to understand your needs.</p>
                    </div>
                    <div class="cta-step">
                        <h3>Custom Proposal</h3>
                        <p>Tailored solution designed for your specific requirements.</p>
                    </div>
                    <div class="cta-step">
                        <h3>Rapid Deployment</h3>
                        <p>Fast implementation with ongoing support and optimization.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- SIMPLE CONTACT FORM (placeholder) -->
    <section class="section section-alt" id="contact-form">
        <div class="container">
            <div class="section-header">
                <h2>Contact Us</h2>
                <p>Share a few details and our team will get back to you within one business day.</p>
            </div>

            <form class="contact-form" method="POST" action="{{ route('contact.submit') }}">
                @csrf

                <input type="hidden" name="form_key" value="home_page">
                <input type="hidden" name="source_page" value="{{ request()->path() }}">

                <div class="form-row">
                    <div class="form-field">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name"
                            value="{{ old('name') }}">
                        @error('name')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>

                    <div class="form-field">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" placeholder="name@company.com"
                            value="{{ old('email') }}">
                        @error('email')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-field">
                        <label for="company">Company</label>
                        <input type="text" id="company" name="company" placeholder="Company name"
                            value="{{ old('company') }}">
                    </div>

                    <div class="form-field">
                        <label for="country">Country</label>
                        <input type="text" id="country" name="country" placeholder="United Kingdom"
                            value="{{ old('country') }}">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-field form-field-full">
                        <label for="message">How can we help?</label>
                        <textarea id="message" name="message" rows="4"
                            placeholder="Tell us about your project, goals, and timelines.">{{ old('message') }}</textarea>
                        @error('message')
                            <small class="text-danger">{{ $message }}</small>
                        @enderror
                    </div>
                </div>

                <button type="submit" class="btn btn-primary">Submit Request</button>
            </form>

        </div>
    </section>

@endsection
