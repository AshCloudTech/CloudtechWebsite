<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />

    {{-- SEO Title (meta_title > title > default) --}}
    <title>@yield('meta_title', @yield('title', 'Cloud Technologies Ltd – British-Built Digital Transformation'))</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    {{-- SEO Description (page override else default) --}}
    <meta name="description" content="@yield('meta_description', 'British-led global digital transformation partner delivering end-to-end solutions for healthcare, education, travel, recruitment, and public sector organizations worldwide.')">

    {{-- Keywords (optional) --}}
    @hasSection('meta_keywords')
        <meta name="keywords" content="@yield('meta_keywords')">
    @endif

    <meta name="robots" content="index, follow">

    {{-- Canonical --}}
    <link rel="canonical" href="@yield('canonical', url()->current())" />

    @php
        $faviconUrl = !empty($globalCompany?->favicon_path)
            ? asset(ltrim($globalCompany->favicon_path, '/'))
            : asset('assets/images/favicon.png');

        $ogImageUrl = !empty($globalCompany?->og_image_path)
            ? asset(ltrim($globalCompany->og_image_path, '/'))
            : asset('assets/images/og-default.jpg'); // create this fallback image if not existing
    @endphp

    {{-- Favicon --}}
    <link rel="icon" href="{{ $faviconUrl }}" type="image/png">
    <link rel="apple-touch-icon" href="{{ $faviconUrl }}">

    {{-- Open Graph (Social Sharing) --}}
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Cloud Technologies Ltd">
    <meta property="og:locale" content="en_GB">
    <meta property="og:title" content="@yield('og_title', @yield('meta_title', @yield('title', 'Cloud Technologies Ltd')))">
    <meta property="og:description" content="@yield('og_description', @yield('meta_description', 'British-led global digital transformation partner delivering end-to-end solutions worldwide.'))">
    <meta property="og:url" content="@yield('canonical', url()->current())">
    <meta property="og:image" content="@yield('og_image', $ogImageUrl)">

    {{-- Twitter Card --}}
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="@yield('twitter_title', @yield('og_title', @yield('meta_title', @yield('title', 'Cloud Technologies Ltd'))))">
    <meta name="twitter:description" content="@yield('twitter_description', @yield('og_description', @yield('meta_description', 'British-led global digital transformation partner.')))">
    <meta name="twitter:image" content="@yield('twitter_image', @yield('og_image', $ogImageUrl))">

    {{--  Google Search Console Verification --}}
    <meta name="google-site-verification" content="rxQnU-7ZRd02KJKnFK-2P3jP4xk0WI2QDEhf1NCogz8" />

    {{--  Google Analytics (gtag.js) --}}
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-QFQG0JPV04"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){ dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'G-QFQG0JPV04');
    </script>

    {{-- Fonts --}}
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700;900&display=swap" rel="stylesheet">

    {{-- Extra meta from pages (if any) --}}
    @yield('meta_tags')

    {{-- Page-specific CSS --}}
    @stack('styles')

    <link rel="stylesheet" href="{{ asset('assets/audit/audit-modal.css') }}">
</head>

<body>
    {{-- HEADER --}}
    @include('layouts.header')

    {{-- MAIN --}}
    <main>
        @yield('content')
    </main>

    {{-- FOOTER --}}
    @include('layouts.footer')

    @include('partials.consultation')

    {{-- Flash nodes (must exist before JS runs) --}}
    @if (session('success'))
        <div id="global-flash-success" data-message="{{ session('success') }}"></div>
    @endif

    @if (session('error'))
        <div id="global-flash-error" data-message="{{ session('error') }}"></div>
    @endif

    {{-- Page scripts first --}}
    @stack('scripts')

    {{-- Global scripts always --}}
    <script src="{{ asset('assets/js/forms-global.js') }}" defer></script>
    <script src="{{ asset('assets/audit/audit-modal.js') }}" defer></script>

    @include('partials.audit-modal')

    {{-- Floating WhatsApp Chat Button --}}
    <a href="https://wa.me/{{ $globalCompany?->whatsapp }}"
       class="whatsapp-float"
       target="_blank"
       rel="noopener"
       aria-label="Chat with us on WhatsApp">
        <span class="whatsapp-text">
            <strong>We’re Online</strong><br>
            Chat With Us Now
        </span>
        <span class="whatsapp-icon">
            <i data-lucide="message-circle"></i>
        </span>
    </a>
</body>
</html>